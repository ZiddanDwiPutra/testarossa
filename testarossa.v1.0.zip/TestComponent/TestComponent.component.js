import React from 'react';

const TestComponent = () => {
  return (
    <div>
      <h1>TestComponent Component</h1>
    </div>
  );
};

export default TestComponent;
